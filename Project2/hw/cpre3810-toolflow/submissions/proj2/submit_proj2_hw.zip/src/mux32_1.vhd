-- 32:1 multiplexer for 32-bit wide data
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity mux32_1 is
    port (
        data_in : in  std_logic_vector(32*32-1 downto 0); 
        sel     : in  std_logic_vector(4 downto 0);
        y       : out std_logic_vector(31 downto 0)
    );
end entity;

architecture rtl of mux32_1 is
begin
    process(data_in, sel)
        variable index : integer;
    begin
        index := to_integer(unsigned(sel));
        y <= data_in((index+1)*32-1 downto index*32);
    end process;
end architecture;