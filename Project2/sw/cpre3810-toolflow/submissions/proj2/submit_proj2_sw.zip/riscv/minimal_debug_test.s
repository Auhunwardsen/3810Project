# Comprehensive debug test for processor validation
# Tests each component systematically to isolate bugs

.data
test_mem: .word 0x12345678, 0xABCDEF00, 0x11111111, 0x22222222

.text
.globl main

main:
    # ========== PHASE 1: Basic I-Type Instructions ==========
    # Test ADDI with different immediate values
    addi x1, x0, 1      # x1 = 1 (test small positive)
    addi x2, x0, -1     # x2 = -1 (test negative)  
    addi x3, x0, 255    # x3 = 255 (test max 8-bit positive)
    addi x4, x0, -256   # x4 = -256 (test min 9-bit negative)
    addi x5, x0, 0      # x5 = 0 (test zero)
    
    # Wait many cycles before next test
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # ========== PHASE 2: R-Type Instructions ==========  
    # Test ADD operations (should be x1+x2 = 1+(-1) = 0)
    add x6, x1, x2      # x6 = x1 + x2 = 1 + (-1) = 0
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Test SUB operations (should be x3-x4 = 255-(-256) = 511)
    sub x7, x3, x4      # x7 = x3 - x4 = 255 - (-256) = 511
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Test AND operations (should be x1&x3 = 1&255 = 1)
    and x8, x1, x3      # x8 = x1 & x3 = 1 & 255 = 1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    # Test OR operations (should be x1|x2 = 1|(-1) = -1)
    or x9, x1, x2       # x9 = x1 | x2 = 1 | (-1) = -1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Test XOR operations (should be x1^x1 = 0)
    xor x10, x1, x1     # x10 = x1 ^ x1 = 1 ^ 1 = 0
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # ========== PHASE 3: Shift Instructions ==========
    # Test left shift (should be 1 << 2 = 4)
    slli x11, x1, 2     # x11 = x1 << 2 = 1 << 2 = 4
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Test right logical shift (should be 255 >> 1 = 127)
    srli x12, x3, 1     # x12 = x3 >> 1 = 255 >> 1 = 127
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Test right arithmetic shift (should be -1 >>> 1 = -1)
    srai x13, x2, 1     # x13 = x2 >>> 1 = -1 >>> 1 = -1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # ========== PHASE 4: Comparison Instructions ==========
    # Test set less than (should be 1 < 255 = 1)
    slt x14, x1, x3     # x14 = (x1 < x3) = (1 < 255) = 1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Test set less than immediate (should be 255 < 300 = 1)
    slti x15, x3, 300   # x15 = (x3 < 300) = (255 < 300) = 1
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # ========== PHASE 5: U-Type Instructions ==========
    # Test LUI (Load Upper Immediate)
    lui x16, 0x12345    # x16 = 0x12345000
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Test AUIPC (Add Upper Immediate to PC)
    auipc x17, 0x1000   # x17 = PC + 0x1000000
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # ========== PHASE 6: Memory Instructions ==========
    # Use a simple base address (assume data starts at 0x10000000)
    lui x18, 0x10000    # x18 = 0x10000000 (base data address)
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Store some test values first
    addi x20, x0, 0x123 # x20 = 0x123 (test value 1)
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    sw x20, 0(x18)      # store 0x123 to mem[0x10000000]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    addi x20, x0, 0x456 # x20 = 0x456 (test value 2)  
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    sw x20, 4(x18)      # store 0x456 to mem[0x10000004]
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Test load word (should load back what we stored)
    lw x19, 0(x18)      # x19 = mem[0x10000000] = 0x123
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    lw x21, 4(x18)      # x21 = mem[0x10000004] = 0x456
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # ========== PHASE 7: Branch Instructions ==========
    # Test BEQ (should branch) - need 3 NOPs after branch for EX stage resolution
    beq x1, x1, branch_test1    # x1 == x1, should branch
    nop                         # Branch delay slot 1
    nop                         # Branch delay slot 2  
    nop                         # Branch delay slot 3
    addi x22, x0, 999           # should NOT execute (after 3 NOPs)
    
branch_test1:
    addi x22, x0, 1001          # x22 = 1001 (good value)
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # Test BNE (should branch) - need 3 NOPs after branch for EX stage resolution
    bne x1, x2, branch_test2    # x1 != x2, should branch
    nop                         # Branch delay slot 1
    nop                         # Branch delay slot 2
    nop                         # Branch delay slot 3  
    addi x23, x0, 999           # should NOT execute (after 3 NOPs)
    
branch_test2:
    addi x23, x0, 1002          # x23 = 1002 (good value)
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # ========== PHASE 8: Simple Jump Test (No Return) ==========
    # Test simple jump forward (no return to avoid infinite loop) - need 3 NOPs for EX stage resolution
    jal x24, simple_jump        # x24 = return address, jump forward
    nop                         # Jump delay slot 1
    nop                         # Jump delay slot 2
    nop                         # Jump delay slot 3
    addi x25, x0, 999           # should NOT execute (bad value, after 3 NOPs)
    
simple_jump:
    # Simple jump target - just set a marker value
    addi x25, x0, 1003          # x25 = 1003 (good value - proves jump worked)
    addi x26, x0, 1004          # x26 = 1004 (mark we were here)
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    nop
    
    # ========== TEST COMPLETE ==========
    # Final signature values for validation:
    # x1=1, x2=-1, x3=255, x6=0, x7=511, x8=1, x9=-1, x10=0
    # x11=4, x12=127, x13=-1, x14=1, x15=1, x19=0x123, x21=0x456
    # x22=1001, x23=1002, x25=1003, x26=1004
    wfi
