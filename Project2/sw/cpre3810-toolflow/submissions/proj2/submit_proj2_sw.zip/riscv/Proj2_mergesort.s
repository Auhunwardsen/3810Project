
# Proj1_mergesort.s
#   Recursive Merge Sort implementation.
# 
# Expected behavior:
#   Sorts the array in ascending order in-place.
# 
# Registers:
#   a0 - base address of array
#   a1 - left index
#   a2 - right index
#   t0-t6, a3 - temporaries
#   sp - stack pointer (grows downward)

.data
array:  .word 8, 3, 5, 4, 7, 2, 6, 1   # unsorted array
n:      .word 8

.text
.globl main

##############################################################
# main
# - Initializes stack pointer and calls mergesort
##############################################################
main:
	# Initialize stack pointer - use explicit LUI
	lui  sp, 0x80000        # sp = 0x80000000
	
	# load base address - use simple base address
	lui  a0, %hi(array)     # a0 = 0x10000000 (simple base)
	nop
	nop
	addi a0, a0, %lo(array)
	addi a1, x0, 0       # left = 0 (explicit ADDI)
	lui  t0, %hi(n)
	nop
	nop
   	lw   t0, %lo(n)(t0)           # Load n value (pseudo-instruction)
   	nop                  # NOPs after load before use (may expand)
   	nop
   
	addi a2, t0, -1      # right = n-1
	jal  ra, mergesort
	nop                  # NOPs after jal
	nop
	nop
	nop
	beq zero, zero, done
	nop
	nop
	nop

##############################################################
# mergesort(a0=array, a1=left, a2=right)
#   if left >= right: return
#   mid = (left + right) / 2
#   mergesort(array, left, mid)
#   mergesort(array, mid+1, right)
#   merge(array, left, mid, right)
##############################################################
mergesort:
    	bge  a1, a2, ms_return      # if left >= right, return
    	nop
    	nop
    	nop

    	add  t0, a1, a2             # t0 = left + right
		nop
		nop
    	srai t1, t0, 1              # t1 = mid = (left+right)/2

    	# push ra, a1, a2, t1 (mid)
   		addi sp, sp, -16
		nop
		nop
    	sw   ra, 12(sp)
    	sw   a1, 8(sp)
    	sw   a2, 4(sp)
    	sw   t1, 0(sp)

    	# call mergesort(array, left, mid)
    	mv   a2, t1
    	jal  ra, mergesort
		nop
    	nop
    	nop
		nop

    	# call mergesort(array, mid+1, right)
   		lw   t1, 0(sp)
    	nop                     # NOPs after load before use
    	nop
    	addi a1, t1, 1
    	lw   a2, 4(sp)
    	jal  ra, mergesort
    	nop
    	nop
		nop
		nop

    	# call merge(array, left, mid, right)
    	lw   t1, 0(sp)
    	lw   a1, 8(sp)
    	lw   a2, 4(sp)
    	jal  ra, merge
    	nop
		nop
    	nop
		nop

    	# pop ra and locals
    	lw   ra, 12(sp)
		nop
    	addi sp, sp, 16
    	
ms_return:
   		jr   ra
		nop
		nop


##############################################################
# merge(a0=array, a1=left, a2=right)
# mid stored in t1
#   Uses t0�t6 as temporaries.
#   Creates a local buffer on stack to hold merged elements.
##############################################################
merge:
    	# compute mid+1 and setup temp ptr
		addi sp, sp, -64        # local buffer (enough for 16 ints)
		nop
		nop
    	mv   t2, sp             # t2 = temp pointer
   		addi t3, t1, 1          # j = mid+1
    	mv   t4, a1             # i = left
		nop
    	mv   t5, zero           # k = 0
merge_loop:
    	bgt  t4, t1, copy_right
    	nop
    	nop
    	nop
   	 	bgt  t3, a2, copy_left
    	nop
    	nop
    	nop

    	slli t6, t4, 2
		nop
		nop
    	add  t6, a0, t6
		nop
		nop
    	lw   s0, 0(t6)          # s0 = arr[i]
    	slli a3, t3, 2
		nop
		nop
    	add  a3, a0, a3
		nop
		nop
    	lw   s1, 0(a3)          # s1 = arr[j]
    	nop                     # NOPs after load before use
    	nop
    	ble  s0, s1, take_left
    	nop
    	nop
    	nop
# take right
    	sw   s1, 0(t2)
    	addi t3, t3, 1
    	j    next_take
    	nop
    	nop
    	
take_left:
    	sw   s0, 0(t2)
    	addi t4, t4, 1
    
next_take:
    	addi t2, t2, 4
    	addi t5, t5, 1
    	j merge_loop
    	nop
    	nop

copy_left:
    	bgt  t4, t1, copy_right
    	nop
    	nop
    	nop
    	slli t6, t4, 2
		nop
		nop
    	add  t6, a0, t6
		nop
		nop
    	lw   s0, 0(t6)
    	nop                     # NOPs after load before use
    	nop
   		sw   s0, 0(t2)
    	addi t4, t4, 1
		nop
    	addi t2, t2, 4
    	j copy_left
    	nop
    	nop

copy_right:
    	bgt  t3, a2, write_back
    	nop
    	nop
    	nop
    	slli t6, t3, 2
		nop
		nop
    	add  t6, a0, t6
		nop
		nop
    	lw   s0, 0(t6)
    	nop                     # NOPs after load before use
    	nop
    	sw   s0, 0(t2)
    	addi t3, t3, 1
		nop
    	addi t2, t2, 4
    	j copy_right
    	nop
    	nop

write_back:
    	mv   t2, sp
    	mv   t4, a1
    	
wb_loop:
    	bgt  t4, a2, wb_done
    	nop
    	nop
    	nop
    	lw   s0, 0(t2)
    	slli t6, t4, 2
		nop
		nop
    	add  t6, a0, t6
		nop
		nop
    	sw   s0, 0(t6)
    	addi t2, t2, 4
    	addi t4, t4, 1
    	j wb_loop
    	nop
    	nop

wb_done:
    	addi sp, sp, 64
   		jr ra
		nop
		nop

done:
	wfi
